Explicación de los ficheros entregados:
 - tablas.sql                           Fichero de creación de las tablas básicas necesarias
 - BILIOTK_PACKAGE.SQL                  Fichero con el package de los nombres de las funciones obligatorias
 - BIBLIOTK_BODY.SQL                    Fichero con el package del cuerpo de las funciones obligatorias
 - BIBLIOTK_ESQUEMA_PARTE2.SQL          Fichero con Las tablas y funciones opcionales
 - TRIGGERS_Y_PRUEBAS.SQL               Fichero con todos los tiggers, tablas de historial y batería de pruebas